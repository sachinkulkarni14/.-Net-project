﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public interface IHotelComponent
    {
        void UserSignup(Signup user);
        Signup UserLogin(string userid, string Password);
        void AddRoomDetails(RoomsDetail rooms);

        List<RoomsDetail> GetRoomDetails();
        void AddBookingDetails(Booking booking);

        List<Booking> BookedReceipt();

        Admin AdminLogin(string email, string password);

        void UpdateRoomDetails(RoomsDetail rooms);
        void DeleteRoomDetails(int no);

    }
    public class HotelFactory
    {
        public static IHotelComponent GetComponent()
        {
            return new HotelComponent();
        }
    }
    public class HotelComponent : IHotelComponent
    {
        static IDataComponent component = DataFactory.CreateComponent();

        public void AddBookingDetails(Booking booking)
        {
            component.AddBookingDetails(booking);
        }

        public void AddRoomDetails(RoomsDetail rooms)
        {
            component.AddRoomDetails(rooms);
        }

        public Admin AdminLogin(string email, string password)
        {
            var admin = component.AdminLogin(email, password);
            return admin;
        }

        public List<Booking> BookedReceipt()
        {
            return component.BookedReceipt();
        }

        public void DeleteRoomDetails(int no)
        {
            component.DeleteRoomDetails(no);
        }

        public List<RoomsDetail> GetRoomDetails()
        {
            return component.GetRoomDetails();
        }

        public void UpdateRoomDetails(RoomsDetail rooms)
        {
            component.UpdateRoomDetails(rooms);
        }

        public Signup UserLogin(string userid, string Password)
        {
            return component.UserLogin(userid, Password);
        }

        public void UserSignup(Signup user)
        {
            component.UserSignup(user);
        }
    }


}
