﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace HotelManagementMVC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Homepage()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Homepage(string AdminEmail, string Password)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44373/api/Admin");

                //HTTP POST
                var responseTask = client.GetAsync("Admin?email=" + AdminEmail + "&pwd=" + Password);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var postTask = result.Content.ReadAsAsync<bool>();
                    postTask.Wait();
                    var rst = postTask.Result;
                    if (rst)
                    {


                        return RedirectToAction("AddRoomDetails", "RoomDetails");
                    }
                    else
                    {

                        ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");
                    }
                }
                return View();

            }


        }
    }
}