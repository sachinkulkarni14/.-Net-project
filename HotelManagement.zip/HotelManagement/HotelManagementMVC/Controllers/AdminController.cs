﻿using DAL;
using Hotel_Management.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Hotel_Management;
using BAL;

namespace HotelManagementMVC.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult AddAdmin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddAdmin(Adminclass admin)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44373/api/Admin");


                var postTask = client.PostAsJsonAsync<Adminclass>("Admin", admin);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("RoomDetails");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(admin);
        }







        public ActionResult AdminLogin()
        {
            return View();
        }


        [HttpPost]
        public ActionResult AdminLogin(string AdminEmail, string Password)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44373/api/Admin");

                //HTTP POST
                var responseTask = client.GetAsync("Admin?email=" + AdminEmail + "&pwd="+Password);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var postTask = result.Content.ReadAsAsync<bool>();
                    postTask.Wait();
                    var rst = postTask.Result;
                    if (rst)
                    {


                        return RedirectToAction("AddRoomDetails","RoomDetails");
                    }
                    else
                    {

                        ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");
                    }
                }
                return View();

            }


        }
    }
}




          
