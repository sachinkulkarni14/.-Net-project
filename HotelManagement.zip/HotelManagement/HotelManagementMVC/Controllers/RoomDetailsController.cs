﻿using DAL;
using Hotel_Management.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace HotelManagementMVC.Controllers
{
    public class RoomDetailsController : Controller
    {
        
        public ActionResult AddRoomDetails()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddRoomDetails (HotelRoomsDetail rooms)
        {
            
        
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44373/api/RoomDetails");

             
                
                var postTask = client.PostAsJsonAsync<HotelRoomsDetail>("RoomDetails",rooms);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Homepage","Home");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(rooms);
        }
       
            public ActionResult GetRoomDetails()
            {
                IEnumerable<HotelRoomsDetail> rooms = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44373/api/RoomDetails");
               
                    var responseTask = client.GetAsync("RoomDetails");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<HotelRoomsDetail>>();
                        readTask.Wait();

                        rooms = readTask.Result;
                    }
                    else 
                    {
                     

                        rooms = Enumerable.Empty<HotelRoomsDetail>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
                return View(rooms);
            }        
               

                public ActionResult UpdateRoomDetails(int id)
                {
                    HotelRoomsDetail hotel = null;

                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("https://localhost:44373/api/RoomDetails");
                       
                        var responseTask = client.GetAsync("RoomDetails");
                        responseTask.Wait();

                        var result = responseTask.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsAsync<HotelRoomsDetail>();
                            readTask.Wait();

                            hotel = readTask.Result;
                        }
                    }

                    return View(hotel);
                }
       
         
            public ActionResult DeleteRoomDetails()
            {
                IList<HotelRoomsDetail> rooms = null;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44373/api/RoomDetails");
                   
                    var responseTask = client.GetAsync("RoomsDetail");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<HotelRoomsDetail>>();
                        readTask.Wait();

                        rooms = readTask.Result;
                    }
                }

                return View(rooms);
            }

            public ActionResult Delete(int id)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:64189/api/");

              
                    var deleteTask = client.DeleteAsync("RoomsDetail/" + id.ToString());
                    deleteTask.Wait();

                    var result = deleteTask.Result;
                    if (result.IsSuccessStatusCode)
                    {

                        return RedirectToAction("HotelRoomsDetail");
                    }
                }

                return RedirectToAction("HotelRoomsDetail");
            }

        }
    }
        
    

