﻿using DAL;
using Hotel_Management.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace HotelManagementMVC.Controllers
{
    public class BookingController : Controller
    {
        // GET: Booking
        public ActionResult AddBookingDetails()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddBookingDetails(UserBooking user)
        {


            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44373/api/Booking");


                
                var postTask = client.PostAsJsonAsync<UserBooking>("Booking", user);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("GetBookingDetails","BookingDetails");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View(user);
        }
        public ActionResult GetBookingDetails()
        {
            IEnumerable<UserBooking> rooms = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44373/api/Booking");
                
                var responseTask = client.GetAsync("Booking");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<UserBooking>>();
                    readTask.Wait();

                    rooms = readTask.Result;
                    return RedirectToAction("Homepage", "Home");
                }
                else
                { 

                    rooms = Enumerable.Empty<UserBooking>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(rooms);
        }


    }
}