﻿using Hotel_Management.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace HotelManagementMVC.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        

            public ActionResult UserSignup()
            {
                return View();
            }

            [HttpPost]
            public ActionResult UserSignup(UserRegister user)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44373/api/User");

                 
                    var postTask = client.PostAsJsonAsync<UserRegister>("User", user);
                    postTask.Wait();

                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("UserLogin","User");
                    }
                }

                ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

                return View(user);
            }
        public ActionResult UserLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserLogin(string Userid, string Password)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44373/api/Admin");

            
                var responseTask = client.GetAsync("User?userid=" + Userid + "&pwd=" + Password);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var postTask = result.Content.ReadAsAsync<bool>();
                    postTask.Wait();
                    var rst = postTask.Result;
                    if (rst)
                    {


                        return RedirectToAction("GetRoomDetails", "RoomDetails");
                    }
                    else
                    {

                        ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");
                    }
                }
                return View();

            }


        }
    }
    }
