﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DAL
{
    public interface IDataComponent
    {
        void UserSignup(Signup user);
        bool UserLogin(string userid, string Password);
        void AddRoomDetails(RoomsDetail rooms);

        List<RoomsDetail> GetRoomDetails();
        void AddBookingDetails(Booking booking);

        List<Booking> GetBookedReceipt();

        bool AdminLogin(string AdminEmail, string Password);

        void UpdateRoomDetails(RoomsDetail rooms);
        void DeleteRoomDetails(int No);
        void AdminRegister(Admin admin);

    }
    public class DataFactory
    {
        public static IDataComponent CreateComponent()
        {
            return new DataComponent();
        }
    }
    public class DataComponent : IDataComponent

    {
        static HotelManagement hotel = new HotelManagement();






        public void AddBookingDetails(Booking booking)
        {
            try
            {
                var bookings = hotel.Bookings.Add(booking);
                hotel.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
                
            }

        }


        public void AddRoomDetails(RoomsDetail rooms)
        {
            try
            {
                var roomdata = hotel.RoomsDetails.Add(rooms);
                hotel.SaveChanges();
            }
            catch(Exception ex)
            {
               throw new Exception( ex.Message);
            }
        }

        public bool AdminLogin(string AdminEmail, string Password)
        {
            try
            {
                var selected = hotel.Admins.FirstOrDefault((u) => ((u.AdminEmail == AdminEmail) && (u.Password == Password)));
                if (selected != null) return true;
                else
                    return false;
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void AdminRegister(Admin admin)
        {
            try
            {
                var data = hotel.Admins.Add(admin);
                hotel.SaveChanges();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Booking> GetBookedReceipt()
        {
            try
            {
                return new HotelManagement().Bookings.ToList();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void DeleteRoomDetails(int No)
        {
            try
            {
                var selected = hotel.RoomsDetails.SingleOrDefault((a) => a.RoomNo == No);
                if (selected == null) throw new Exception("RoomNo not found");
                hotel.RoomsDetails.Remove(selected);
                hotel.SaveChanges();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }


        }

        public List<RoomsDetail> GetRoomDetails()
        {
            try
            {
                return new HotelManagement().RoomsDetails.ToList();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateRoomDetails(RoomsDetail rooms)
        {
            try
            {
                var selected = hotel.RoomsDetails.FirstOrDefault((y) => y.RoomNo == rooms.RoomNo);
                if (selected == null) throw new Exception("Roomno Not found");
                selected.RoomNo = rooms.RoomNo;
                selected.NumberofRooms = rooms.NumberofRooms;
                selected.Price = rooms.Price;
                selected.Roomtype = rooms.Roomtype;
                selected.status = selected.status;
                hotel.SaveChanges();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
;            }
        }



        public bool UserLogin(string userid, string Password)
        {
            try
            {
                var selected = hotel.Signups.FirstOrDefault((x) => ((x.Userid == userid) && (x.Password == Password)));
                if (selected != null) return true;
                else
                    return false;
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        public void UserSignup(Signup user)
        {
            try
            {
                var userdata = hotel.Signups.Add(user);
                hotel.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }



        }

    }
}