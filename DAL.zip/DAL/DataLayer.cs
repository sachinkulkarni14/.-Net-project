﻿using Hotel_Management;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public interface IDataComponent
    {
        void UserSignup(Signup user);
         Signup UserLogin(string userid, string Password);
        void AddRoomDetails(RoomsDetail rooms);

        List<RoomsDetail> GetRoomDetails();
        void AddBookingDetails(Booking booking);

        List<Booking> BookedReceipt();

        Admin AdminLogin(string AdminEmail, string Password);

        void UpdateRoomDetails(RoomsDetail rooms);
        void DeleteRoomDetails(int No);

    }
    public class DataFactory
    {
        public static IDataComponent CreateComponent()
        {
            return new DataComponent();
        }
    }
      public  class DataComponent : IDataComponent

    {
            static HotelManagement hotel = new HotelManagement();

        

        public void AddBookingDetails(Booking booking)
            {
                var bookings = hotel.Bookings.Add(booking);
                hotel.SaveChanges();

            }

            public void AddRoomDetails(RoomsDetail rooms)
            {
                var roomdata = hotel.RoomsDetails.Add(rooms);
                hotel.SaveChanges();
            }

            public Admin AdminLogin(string AdminEmail, string Password)
            {

                var selected = hotel.Admins.FirstOrDefault((u) => (u.AdminEmail == AdminEmail) && (u.Password == Password));
                if (selected == null) throw new Exception("Login failed for the user");
                return selected;
            }

            public List<Booking> BookedReceipt()
            {
                return new HotelManagement().Bookings.ToList();
            }

        public void DeleteRoomDetails(int No)
        {
            var selected=hotel.RoomsDetails.SingleOrDefault((a)=>a.RoomNo==No);
            if (selected == null) throw new Exception("RoomNo not found");
            hotel.RoomsDetails.Remove(selected);
            hotel.SaveChanges(); 

        }

        public List<RoomsDetail> GetRoomDetails()
            {
                return new HotelManagement().RoomsDetails.ToList(); 
            }

        public void UpdateRoomDetails(RoomsDetail rooms)
        {
            var selected = hotel.RoomsDetails.FirstOrDefault((y) => y.RoomNo == rooms.RoomNo);
            if (selected == null) throw new Exception("Roomno Not found");
            selected.RoomNo = rooms.RoomNo;
            selected.NumberofRooms = rooms.NumberofRooms;
            selected.Price = rooms.Price;
            selected.Roomtype = rooms.Roomtype;
            selected.status = selected.status;
            hotel.SaveChanges();
        }

        

        public Signup UserLogin(string userid, string Password)
            {
                var selected = hotel.Signups.FirstOrDefault((x) => (x.Userid == userid) && (x.Password == Password));
                if (selected == null) throw new Exception("Login failed for the user");
                return selected;
            }

            public void UserSignup(Signup user)
            {
                var userdata = hotel.Signups.Add(user);
                hotel.SaveChanges();
            }
        }
    }

    